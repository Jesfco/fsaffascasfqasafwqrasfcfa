# Active Shooter Callout Pack - Version 2.0.0

---

## 📬 Join Our Discord:
For updates, bug reports, or suggestions:  
https://discord.gg/k7u4qXme8j

---

## 📥 Installation Instructions:
1. Place the `.dll` file and any related folders into your **GTA V/Plugins/LSPDFR** directory.
   - If you don't have a `Plugins` folder, create one inside your main GTA V directory.
2. Required dependencies (must already be installed):
   - LSPDFR 0.4.9 or newer
   - Open All Interiors MOD (Any is okay) (recommended for full access to callout locations)

---

## 🛠️ What's New in Version 2.0.0 (April 28, 2025):

### New Content:
- **Added New Callout**:  
  - Active Shooter at University  
    Large campus scenario featuring dynamic suspect and civilian reactions.

### Improvements:
- Optimized suspect and civilian AI behavior.
- Improved entity cleanup for better scene performance.
- Reduced crash risk and improved callout stability.

### Other Changes:
- Full rebranding from Tech Op Studios to TACSIMS.

---

# 🚓 Developed by TACSIMS

---