
===============================
REAL REACTIONS v2.0.0 by Dr. Mamba
===============================

Thank you for downloading Real Reactions — a complete realism overhaul for NPC combat physics in LSPDFR and GTA V.

-------------------------------
FEATURES
-------------------------------
- Weapon-based knockback force (80+ weapons supported)
- Full-body ragdoll reactions based on shot impact
- Taser support with Euphoria-style electrocution
- Seizure-style death animation using force math
- Guaranteed weapon drop when shot or tased
- Melee impact reactions (stumble/flee)
- Optional delayed collapse for realism
- Fully configurable .ini file with comments

-------------------------------
INSTALLATION
-------------------------------
1. Copy RealReactions.dll into your /scripts/ folder.
2. On first run, the plugin will generate RealReactions.ini
   in the same directory with all settings and weapon forces.

-------------------------------
CONFIGURATION (.INI)
-------------------------------
[Settings]
SeizureChance         = 0.0  ; Chance (0.0 to 1.0) NPCs seize before death
AllowTaserEffects     = true ; Enable electrocution + weapon drop on taser
DelayedCollapseChance = 0.45 ; Chance (0.0 to 1.0) NPC staggers before falling
TestMode              = false; Forces seizure every time for testing

[WeaponForces]
All supported weapons and their knockback multipliers (0.1 - 5.0).
Adjust per your taste.

-------------------------------
RECOMMENDATIONS
-------------------------------
- Use with Euphoria Physics Enhancers for best results.
- Lower SeizureChance for performance-sensitive systems.
- Combine with Callout Interface or Realistic Damage mods.

-------------------------------
CREDITS
-------------------------------
Developed by Dr. Mamba
Thanks to the Beta Testers on Discord
Special thanks to @Maminka

-------------------------------
CONTACT
-------------------------------
For support, feedback, or updates:
https://discord.gg/mnv4DKG8GC
https://www.lcpdfr.com/downloads/gta5mods/scripts/50806-realistic-reactions/
